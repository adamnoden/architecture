"""Explicit geometry bounds only: no altered native solve or joint resistance."""
import copy,hashlib,json,math,sys
from pathlib import Path
D=Path(__file__).parent;ROOT=Path('/workspace/scratch/0bcaf9220286/head-fan-work');sys.path.insert(0,str(ROOT/'project/str/studies'))
from wet_support_cage_comparison import comparison_settings,beam_loop,post_bars
from floor_section_model import load_source
P=Path('/tmp/ovid-wet-pad-width120-20261123/width120-q64.full.json');native=json.loads(P.read_text());wet=native['seatedWetSupport'];s=comparison_settings();g=wet['settings'];posts=wet['posts'];h=json.loads((ROOT/'project/had/studies/water-replan.json').read_text())['model'];x,y,w,d=h['stair'];stair=[x,y,x+w,y+d];r0=posts[0]['rectangleXYMm'];lo=g['beamSouthEndYMm'];newlo=r0[1];beamx=[g['beamAxisXMm']-g['beamWidthMm']/2,g['beamAxisXMm']+g['beamWidthMm']/2]
extension=[beamx[0],newlo,beamx[1],lo];overlap=[max(stair[0],extension[0]),max(stair[1],extension[1]),min(stair[2],extension[2]),min(stair[3],extension[3])]
mono_posts=copy.deepcopy(posts)
for p in mono_posts:p['physicalTopZMm']=g['beamTopZMm']
bars=post_bars(mono_posts,s);trials=[]
for name,south in [('current-beam-length',lo),('beam-extended155mm-to-south-post-end',newlo)]:
 gg=copy.deepcopy(g);gg['beamSouthEndYMm']=south;loops=[beam_loop(gg,s,i) for i in (0,1)];R=(s['beamReturnMandrelMm']+s['mainDiameterMm'])/2;zc=gg['beamTopZMm']-gg['beamDepthMm']/2;a=south+s['beamMainFaceMm']+R;b=gg['beamNorthEndYMm']-s['beamMainFaceMm']-R;witnesses=[];no_loop=[]
 for bar in bars:
  px,py,pz=bar['parts'][0]['points'][0];loop=loops[0 if px<gg['beamAxisXMm'] else 1];bx=loop['parts'][0]['points'][0][0]
  if a<=py<=b:z=zc-R;region='bottom-straight'
  elif a-R<=py<a:z=zc-math.sqrt(max(0,R*R-(py-a)**2));region='south-semicircle'
  elif b<py<=b+R:z=zc-math.sqrt(max(0,R*R-(py-b)**2));region='north-semicircle'
  else:no_loop.append({'postBar':bar['id'],'xyMm':[px,py]});continue
  lower=bar['parts'][0]['points'][-1][2]
  assert lower<=z<=pz
  distance=abs(px-bx);witnesses.append({'postBar':bar['id'],'beamLoop':loop['id'],'beamRegion':region,'postPointMm':[px,py,z],'exactAnalyticBeamPointMm':[bx,py,z],'centrelineDistanceMm':distance,'nominalSurfaceClearanceMm':distance-(bar['diameterMm']+loop['diameterMm'])/2,'witnessScope':'One exact point-pair from the owning line/circle formula. Negative surface clearance establishes nominal overlap for this naive vertical continuation only; no alternative cage is excluded.'})
 trials.append({'name':name,'beamSouthEndYMm':south,'postMainTrialTopZMm':g['beamTopZMm']-s['postTopEndInsetMm'],'nominalOverlapWitnesses':witnesses,'postRowsWithoutBeamLoopAtSameY':no_loop,'nativeSolveExecuted':False,'currentCageAccepted':False})
vol=sum((p['rectangleXYMm'][2]-p['rectangleXYMm'][0])*(p['rectangleXYMm'][3]-p['rectangleXYMm'][1])*g['padThicknessMm']/1e9 for p in posts);padG=sum(p['padPhysicalGKN'] for p in posts)
report={'schema':'str-monolithic-wet-joint-geometry-bounds/1','sourceSHA256':load_source(ROOT)['identities'],'nativeControlPath':str(P),'nativeControlSHA256':hashlib.sha256(P.read_bytes()).hexdigest(),'nativeControlRequest':native['request'],'cageSettings':s,'existingPostTopZMm':3010.,'beamSoffitZMm':g['beamTopZMm']-g['beamDepthMm'],'beamCentroidZMm':g['beamTopZMm']-g['beamDepthMm']/2,'beamTopZMm':g['beamTopZMm'],'fullPost10mmGapFillVolumeM3':vol,'addedGapFillCharacteristicGKN':vol*g['concreteUnitWeightKNPerM3'],'removedPadCharacteristicGKN':padG,'netGapFillMinusPadCharacteristicGKN':vol*g['concreteUnitWeightKNPerM3']-padG,'beam155mmExtensionBoxXYMm':extension,'extensionContainedInExistingPostPlan':r0[0]<=extension[0] and r0[1]<=extension[1] and extension[2]<=r0[2] and extension[3]<=r0[3],'actualStairApertureXYMm':stair,'extensionStairPlanOverlapXYMm':overlap,'existingPostTopBelowBeamSoffitMm':10.,'existingPostAlreadyOccupiesSameXYProjection':True,'additionalPlanObstructionClaimed':False,'headroomOrUsableLandingAccepted':False,'straightExtensionEmbedmentAboveSoffitMm':g['beamTopZMm']-s['postTopEndInsetMm']-(g['beamTopZMm']-g['beamDepthMm']),'fullStressH12BasicDevelopmentGoodBondMm':12*s['sourceSteelYieldMPa']/(4*s['sourceGoodBondMPa']),'fullStressH12BasicDevelopmentPoorBondMm':12*s['sourceSteelYieldMPa']/(4*s['sourcePoorBondMPa']),'trials':trials,'sixDOFJointCapacityAccepted':False,'developmentAccepted':False,'monolithicOptionSelected':False,'scope':'Existing frame work maps can represent an authored monolithic beam/post joint. They do not establish 3D force transfer, crack/anchorage/bend capacity, actual reinforcement fit, headroom or buildability. Gapfill union and removed pads must each be charged once; beam extension and any full-height post projection need separate source union subtraction.'}
(D/'monolithic-bounds.json').write_text(json.dumps(report,indent=2,allow_nan=False)+'\n');print(json.dumps({'containment':report['extensionContainedInExistingPostPlan'],'planOverlap':overlap,'gapFillNetG':report['netGapFillMinusPadCharacteristicGKN'],'overlapWitnessCounts':{r['name']:len(r['nominalOverlapWitnesses']) for r in trials},'nominalSurfaceClearanceMm':trials[0]['nominalOverlapWitnesses'][0]['nominalSurfaceClearanceMm']}))
