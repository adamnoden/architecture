import math,unittest
from prototype import transfer
class TraceTest(unittest.TestCase):
    def box(self,cells):return {'model':{},'cells':cells,'contact_points':{p for a,b,c,d in cells for p in ((a,b),(c,b),(c,d),(a,d))}}
    def test_same_fixed_physical_points_have_exact_rigid_work_on_both_meshes(self):
        rows=[{'xyMm':[x,y],'gridMemberId':'actual'} for x,y in ((110,125),(330,180),(710,555),(999,599))]
        coarse=self.box([[0,0,1000,600]])
        fine=self.box([[x,y,x+250,y+150] for x in range(0,1000,250) for y in range(0,600,150)])
        for b in (coarse,fine):
            r=transfer(rows,b);self.assertEqual(r['missingPhysicalPoints'],[]);self.assertTrue(r['nonnegativeTraceWeights']);self.assertLess(r['maximumPartitionResidual'],1e-14);self.assertLess(r['maximumFirstMomentMmResidual'],1e-10);self.assertLess(r['maximumRigidWorkMmResidual'],1e-13)
    def test_point_outside_actual_material_remains_unsupported(self):
        r=transfer([{'xyMm':[500,500],'gridMemberId':'actual'}],self.box([[0,0,250,250]]));self.assertEqual(r['missingPhysicalPoints'],[[500,500]])
    def test_missing_retained_plate_coordinate_rejects(self):
        b=self.box([[0,0,1000,600]]);b['contact_points'].remove((1000,600))
        with self.assertRaisesRegex(ValueError,'unretained'):transfer([{'xyMm':[500,300],'gridMemberId':'actual'}],b)
    def test_nonsupported_points_cannot_add_spring(self):
        r=transfer([{'xyMm':[500,300],'gridMemberId':None}],self.box([[0,0,1000,600]]));self.assertEqual(r['sampleCount'],0)
if __name__=='__main__':unittest.main()
