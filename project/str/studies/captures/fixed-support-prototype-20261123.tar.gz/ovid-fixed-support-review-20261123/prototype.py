"""READ ONLY geometry/virtual-work experiment, not a house solve or new design source."""
import copy, gc, hashlib, inspect, json, math, sys, time
from pathlib import Path
ROOT=Path('/workspace/scratch/0bcaf9220286/head-fan-work')
OUT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'project/str/studies'))
import floor_section_model as fsm
import floor_section_proof as fsp
import vertical_rc_floor as vf
from seated_wet_support import build_support,replacement_cores
from vertical_floor_plate import rectangle_shapes

class Captured(Exception):pass

def digest(value):return hashlib.sha256(json.dumps(value,sort_keys=True,separators=(',',':'),allow_nan=False).encode()).hexdigest()

def geometry(case,source,h,pitch,stations):
    request=copy.deepcopy(case['bearingCase']);request['masonryCase']['verticalCase']['maxPitchMm']=pitch
    box={};original=vf.assemble_vertical_plate
    def capture(cells,*args,**kwargs):
        ctx=inspect.currentframe().f_back.f_locals
        box.update({k:ctx[k] for k in ('model','contacts','cells','ports','port_terms','contact_points','rc_rectangles','ground_rectangles','cap_rectangles','bodies','holes')})
        raise Captured()
    vf.assemble_vertical_plate=capture
    try:
        try:fsm._build_base(request,source['bearing'],additional_receiver_builder=lambda m:build_support(m,case['wetSupport'],h,stations),core_transform=lambda cores,m:replacement_cores(cores,case['wetSupport'],m))
        except Captured:pass
        else:raise ValueError('Owning plate assembly did not reach observation point')
    finally:vf.assemble_vertical_plate=original
    box['courtCornerClosureSetting']=request['masonryCase']['courtCornerClosure']
    model=box['model'];r=model['seatedWetSupport']['receiver']['rectangleXYMm']
    vertical=sorted({p for cell in box['cells'] for p in (cell[1],cell[3]) if r[1]<=p<=r[3]})
    membrane=[p for p in model['joinedFloor']['floor']['coordinateColumns'][1] if r[1]<=p<=r[3]]
    box['attachmentStations']=sorted(set(vertical+membrane));return box

def quadrature(box,order=4):
    import numpy as np
    g,w=np.polynomial.legendre.leggauss(order);model=box['model'];members=vf.grid_member_geometry(model);rows=[]
    for contact in box['contacts']:
        r=contact['rectangleXYMm'];area=(r[2]-r[0])*(r[3]-r[1])/4
        for i,x in enumerate(g):
            for j,y in enumerate(g):
                point=[float((r[0]+r[2])/2+x*(r[2]-r[0])/2),float((r[1]+r[3])/2+y*(r[3]-r[1])/2)]
                ground=vf.grid_vertical_point_terms(model,members,point)
                if ground is None and box['courtCornerClosureSetting'] is not None:
                    # Same owning formed quarter route applied downstream by _build_base;
                    # observe its exact geometry/work map, never invent a receiver.
                    from court_corner_closure import corner_closure_geometry,MODE
                    if box['courtCornerClosureSetting']!={'mode':MODE}:raise ValueError('Changed closure policy')
                    quarter=corner_closure_geometry(model['grid']);body=quarter['boxXYZMm']
                    if not vf.inside(point,[body[0],body[1],body[3],body[4]],1e-8):raise ValueError('Missing route outside owning formed quarter')
                    nodes=[n for n,p in model['model'].nodes.items() if n.startswith('GRID-') and abs(p[0]-quarter['nodeXYMm'][0])<1e-8 and abs(p[1]-quarter['nodeXYMm'][1])<1e-8]
                    if len(nodes)!=1:raise ValueError('Missing actual formed quarter grid node')
                    node=nodes[0];at=model['model'].nodes[node]
                    ground={'memberId':quarter['id'],'terms':[(node,[0,0,1,point[1]-at[1],at[0]-point[0],0])],'topZMm':quarter['gridTopZMm']}
                if ground is None:raise ValueError('Missing actual physical ground route')
                rows.append({'xyMm':point,'areaMm2':float(area*w[i]*w[j]),'ownerId':contact['owner']['id'],'gridMemberId':ground['memberId'],'groundTerms':ground['terms'],'heightMm':3170-ground['topZMm']})
    return rows

def transfer(rows,box):
    rows=[r for r in rows if r['gridMemberId'] is not None]
    model=box['model'];points=box['contact_points'];cells=box['cells'];max_partition=max_xy=max_rigid=0.;positive_weights=True;used=set();missing=[]
    for row in rows:
        x,y=row['xyMm'];eligible=[(i,r) for i,r in enumerate(cells) if r[0]-1e-7<=x<=r[2]+1e-7 and r[1]-1e-7<=y<=r[3]+1e-7]
        if not eligible:missing.append(row['xyMm']);continue
        i,(a,b,c,d)=eligible[0];nodes=((a,b),(c,b),(c,d),(a,d))
        if not all(p in points for p in nodes):raise ValueError('Frozen contact would reference an unretained current plate coordinate')
        n,_,_=rectangle_shapes(2*(x-a)/(c-a)-1,2*(y-b)/(d-b)-1,c-a,d-b)
        max_partition=max(max_partition,abs(sum(n)-1));max_xy=max(max_xy,abs(sum(v*p[0] for v,p in zip(n,nodes))-x),abs(sum(v*p[1] for v,p in zip(n,nodes))-y));positive_weights &= min(n)>=-1e-9;used.add(i)
        # Three same physical rigid modes, in physical mm/rad.
        for f in (lambda X,Y:1.,lambda X,Y:Y/1000,lambda X,Y:-X/1000):
            max_rigid=max(max_rigid,abs(sum(v*f(*p) for v,p in zip(n,nodes))-f(x,y)))
    return {'sampleCount':len(rows),'touchedCurrentPlateCellCount':len(used),'maximumPartitionResidual':max_partition,'maximumFirstMomentMmResidual':max_xy,'maximumRigidWorkMmResidual':max_rigid,'nonnegativeTraceWeights':bool(positive_weights),'missingPhysicalPoints':missing,'scope':'Exact Q4 displacement trace of fixed physical normal quadrature; not a coupled response, finite joint or convergence result.'}

def compact(box):
    model=box['model'];return {'cellsXYMm':box['cells'],'corners':model['joinedFloor']['corners'],'contactSubrectangles':[{'rectangleXYMm':r['rectangleXYMm'],'ownerId':r['owner']['id']} for r in box['contacts']],'wetBeamStationsYMm':[r['u'] for r in model['seatedWetSupport']['receiver']['stations']],'requiredAttachmentStationsYMm':box['attachmentStations']}

def main():
    started=time.time();source=fsm.load_source(ROOT);before=copy.deepcopy(source['identities']);case=dict(fsp.cases(source))['wet-shifted-quadrature8']
    # Existing owning vertical-only control: in-plane500 held. Only numerical geometry observed.
    case['bearingCase']['masonryCase']['verticalCase']['monolithicCase']['houseCase']['joinedCase']['floor']['maxPitchMm']=500
    h=json.loads((ROOT/'project/had/studies/water-replan.json').read_text())['model'];stations=[];history=[]
    for k in range(4):
        boxes={p:geometry(case,source,h,p,stations) for p in (500,250)}
        actual=sorted(set(u for box in boxes.values() for u in box['attachmentStations']));existing=boxes[500]['model']['seatedWetSupport']['receiver']['stations'];native=[s['u'] for s in existing];missing=[u for u in actual if min(abs(u-v) for v in native)>1e-7]
        history.append({'pass':k+1,'frozenStationsBefore':stations,'requiredUnion':actual,'missing':missing});print('geometry-pass',k+1,'cells',{p:len(b['cells']) for p,b in boxes.items()},'missing',len(missing),flush=True)
        if not missing:break
        stations=sorted(set(stations+missing));del boxes;gc.collect()
    else:raise ValueError('Frozen common receiver closure did not converge')
    q={p:quadrature(box) for p,box in boxes.items()}
    ledgers={}
    for p,rows in q.items():
        owners={}
        for row in rows:
            key=row['ownerId']+'|'+str(row['gridMemberId']);r=owners.setdefault(key,[0.,0.,0.]);a=row['areaMm2'];r[0]+=a;r[1]+=a*row['xyMm'][0];r[2]+=a*row['xyMm'][1]
        ledgers[p]=owners
    changes=[]
    for key in set(ledgers[500])|set(ledgers[250]):
        delta=[a-b for a,b in zip(ledgers[250].get(key,[0.]*3),ledgers[500].get(key,[0.]*3))]
        if max(abs(v) for v in delta)>1e-4:changes.append({'ownerAndReceiver':key,'areaDeltaMm2':delta[0],'firstMomentDeltaMm3':delta[1:]})
    report={'schema':'str-fixed-physical-normal-quadrature-readonly-prototype/1','sourceSHA256':before,'request':case,'history':history,'ordinaryNumericalFibreCount':{p:len(r) for p,r in q.items()},'frozen500ToPlate500':transfer(q[500],boxes[500]),'frozen500ToPlate250':transfer(q[500],boxes[250]),'physicalOwnerReceiverPartitionChanges':sorted(changes,key=lambda r:-abs(r['areaDeltaMm2'])),'totalAreaMm2':{p:sum(r['areaMm2'] for r in rows) for p,rows in q.items()},'missingGroundContactAreaMm2':{p:sum(r['areaMm2'] for r in rows if r['gridMemberId'] is None) for p,rows in q.items()},'sameActualBeamStations':compact(boxes[500])['wetBeamStationsYMm']==compact(boxes[250])['wetBeamStationsYMm'],'candidateAccepted':False,'completeHouseProof':False,'coupledSolveExecuted':False,'physicalJointDefined':False,'elapsedSeconds':time.time()-started}
    if fsm.load_source(ROOT)['identities']!=before:raise ValueError('Source changed during passive geometry experiment')
    for p,box in boxes.items():(OUT/f'geometry-{p}.json').write_text(json.dumps(compact(box),allow_nan=False))
    (OUT/'frozen-normal-q4.json').write_text(json.dumps(q[500],allow_nan=False));(OUT/'report.json').write_text(json.dumps(report,indent=2,allow_nan=False)+'\n')
    print('written report',report['elapsedSeconds'],flush=True)
if __name__=='__main__':main()
