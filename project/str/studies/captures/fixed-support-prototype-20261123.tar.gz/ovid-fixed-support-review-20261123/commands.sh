#!/bin/sh
set -eu
cd /workspace/scratch/0bcaf9220286/head-fan-work
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 python -B /tmp/ovid-fixed-support-review-20261123/prototype.py
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 python -B /tmp/ovid-fixed-support-review-20261123/prototype_test.py -v
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 python -B /tmp/ovid-fixed-support-review-20261123/monolithic_bounds.py
# Earlier scratch draft deliberately stopped on the known court-SW missing
# quarter before applying its owning downstream closure map; current prototype
# observes the existing source-owned quarter rather than inventing a support.
# Earlier unittest absolute-module invocation was invalid; the direct script
# command above ran all four intended tests successfully.
