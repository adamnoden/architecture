"""Explicit ideal four-node compression-fan equilibrium; no finite-node capacity."""
import json,sys,math,hashlib
from pathlib import Path
D=Path(__file__).parent;ROOT=Path('/workspace/scratch/0bcaf9220286/architecture');sys.path.insert(0,str(ROOT/'project/str/studies'))
from wet_support_cage_comparison import comparison_settings,build_paths
from wet_post_head_duties import post_duty,section_wrench
s=comparison_settings();s['postTopLevelRaiseMm']=10.;cases={k:json.loads((D/(v+'.full.json')).read_bytes()) for k,v in [('width220','width220'),('width140','width140')]};records={}
for label,n in cases.items():
 main,links=build_paths(n['seatedWetSupport'],s);posts=[]
 for index,p in enumerate(n['seatedWetSupport']['posts']):
  rect=p['rectangleXYMm'];cx=(rect[0]+rect[2])/2;cy=(rect[1]+rect[3])/2;hx=(rect[2]-rect[0])/2-s['linkNominalCoverMm']-s['linkDiameterMm']/2;hy=(rect[3]-rect[1])/2-s['linkNominalCoverMm']-s['linkDiameterMm']/2
  perimeters=[r for r in links if r['id'].startswith(f'STR/WET-CAGE/post/{index}/link/') and '/cross/' not in r['id']]
  def plane(path):
   values=[q[2] for part in path['parts'] for q in part['points']];return (min(values)+max(values))/2
  hoop=sorted(perimeters,key=plane,reverse=True)[1];level=plane(hoop);H=p['physicalTopZMm']-level
  straight=[]
  for part in hoop['parts']:
   if part['kind']!='line':continue
   a,b=part['points']
   if abs(a[2]-level)>1e-7 or abs(b[2]-level)>1e-7:continue
   if abs(a[0]-b[0])<1e-7 and abs(a[1]-b[1])>1e-7:straight.append({'axis':'Y','constantMm':a[0]-cx,'actualEndpointsXYZMm':[a,b]})
   elif abs(a[1]-b[1])<1e-7 and abs(a[0]-b[0])>1e-7:straight.append({'axis':'X','constantMm':a[1]-cy,'actualEndpointsXYZMm':[a,b]})
  xs=sorted(set(r['constantMm'] for r in straight if r['axis']=='Y'));ys=sorted(set(r['constantMm'] for r in straight if r['axis']=='X'))
  if len(xs)!=2 or len(ys)!=2 or abs(xs[0]+xs[1])>1e-8 or abs(ys[0]+ys[1])>1e-8:raise ValueError('Actual hoop legs do not form the required centred orthogonal fan axes')
  hx,hy=xs[1],ys[1]
  forces=[{'id':r['id'],'xMm':r['pointXYZMm'][0]-cx,'yMm':r['pointXYZMm'][1]-cy,'forceDownKN':r['normalCompressionKN']} for r in n['seatedWetSupport']['contactFibres'] if r['receiverIndex']==index]
  g=n['request']['bearingCase']['masonryCase']['verticalCase']['monolithicCase']['houseCase']['boundary']['physicalGFactor'];forces.append({'id':'actual-factored-pad-G','xMm':p['padCentreXYMm'][0]-cx,'yMm':p['padCentreXYMm'][1]-cy,'forceDownKN':g*p['padPhysicalGKN']})
  unsupported=[r for r in forces if r['forceDownKN']>1e-10 and (abs(r['xMm'])>hx or abs(r['yMm'])>hy)]
  row={'id':p['id'],'actualHoopId':hoop['id'],'actualStraightLegs':straight,'fanDepthMm':H,'virtualIntersectionHalfAxesXYMm':[hx,hy],'positiveTopLoadsOutboardVirtualFan':len(unsupported),'unsupported':bool(unsupported),'scope':'Virtual nodes at intersections of the actual straight hoop-leg axes; these points are not points on the rounded bar. Finite bend/node geometry, concrete stress, tie anchorage, strain compatibility and lower-section force spreading are NOT proved.'}
  if not unsupported:
   nodes={(sx,sy):{'sx':sx,'sy':sy,'xyzRelativeToHeadMm':[sx*hx,sy*hy,-H],'incomingStrutForceKN':[0.,0.,0.]} for sx in (-1,1) for sy in (-1,1)};maximum_top_h=0.;struts=[]
   for load in forces:
    total=[0.,0.,0.]
    for (sx,sy),node in nodes.items():
     w=(1+sx*load['xMm']/hx)*(1+sy*load['yMm']/hy)/4;f=load['forceDownKN']*w;vector=[f*(sx*hx-load['xMm'])/H,f*(sy*hy-load['yMm'])/H,-f]
     for i in range(3):node['incomingStrutForceKN'][i]+=vector[i];total[i]+=vector[i]
     struts.append({'loadId':load['id'],'bottomNode':[sx,sy],'weight':w,'verticalCompressionKN':f,'compressiveAxialForceKN':math.sqrt(sum(z*z for z in vector))})
    maximum_top_h=max(maximum_top_h,abs(total[0]),abs(total[1]))
   ties=[]
   for sy in (-1,1):
    left=nodes[-1,sy]['incomingStrutForceKN'][0];right=nodes[1,sy]['incomingStrutForceKN'][0];assert abs(left+right)<1e-10;ties.append({'axis':'X','fixedSign':sy,'forceKN':right,'oppositeNodeResidualKN':left+right})
   for sx in (-1,1):
    south=nodes[sx,-1]['incomingStrutForceKN'][1];north=nodes[sx,1]['incomingStrutForceKN'][1];assert abs(south+north)<1e-10;ties.append({'axis':'Y','fixedSign':sx,'forceKN':north,'oppositeNodeResidualKN':south+north})
   w=[0.]*6
   for load in forces:
    F=load['forceDownKN'];x,y=load['xMm'],load['yMm'];w[2]-=F;w[3]-=y*F/1000;w[4]+=x*F/1000
   for (sx,sy),node in nodes.items():
    V=-node['incomingStrutForceKN'][2];x,y,z=node['xyzRelativeToHeadMm'];w[2]+=V;w[3]+=y*V/1000;w[4]-=x*V/1000
   actual=post_duty(p);bodyG=actual['bodyGravityKNPerMm']*H
   body_wrench=[0.,0.,-bodyG,0.,0.,0.];body_bottom_reaction=[0.,0.,bodyG,0.,0.,0.]
   w=[a+b+c for a,b,c in zip(w,body_wrench,body_bottom_reaction)]
   bottom_actual=section_wrench(actual['headWrenchKN_KNmm'],actual['bodyGravityKNPerMm'],H)
   bottom_interface=[0.,0.,sum(l['forceDownKN'] for l in forces)+bodyG,sum(nd['xyzRelativeToHeadMm'][1]*(-nd['incomingStrutForceKN'][2])/1000 for nd in nodes.values()),-sum(nd['xyzRelativeToHeadMm'][0]*(-nd['incomingStrutForceKN'][2])/1000 for nd in nodes.values()),0.]
   bottom_delta=[a+b/(1000 if i>=3 else 1) for i,(a,b) in enumerate(zip(bottom_interface,bottom_actual))]
   top=[0,0,-sum(l['forceDownKN'] for l in forces),-sum(l['forceDownKN']*l['yMm']/1000 for l in forces),sum(l['forceDownKN']*l['xMm']/1000 for l in forces),0];source_delta=[a-b/(1000 if i>=3 else 1) for i,(a,b) in enumerate(zip(top,actual['headWrenchKN_KNmm']))]
   area=math.pi*s['linkDiameterMm']**2/4;capacity=area*s['sourceSteelYieldMPa']*s['comparisonSteelFraction']/1000
   for t in ties:
    t['nominalSingleH8SteelOnlyCapacityKN']=capacity;t['necessarySteelOnlyRatio']=t['forceKN']/capacity;t['requiredBarStressMPaAtComparisonFraction']=t['forceKN']*1000/(area*s['comparisonSteelFraction']);t['basicPoorBondLengthMm']=s['linkDiameterMm']*t['requiredBarStressMPaAtComparisonFraction']/(4*s['sourcePoorBondMPa'])
   row.update(bottomNodes=list(nodes.values()),ties=ties,headSourceWrenchResidualKN_KNm=source_delta,globalFreeBodyResidualKN_KNm=w,maximumTopNodeHorizontalResidualKN=maximum_top_h,strutCount=len(struts),maximumIndividualDiscretisedStrutCompressionKN=max(r['compressiveAxialForceKN'] for r in struts),actualPostSelfGInFanDepthKN=bodyG,actualUniformPostBodyWrenchAtMidDepthKN_KNm=body_wrench,actualUniformPostBodyBottomReactionKN_KNm=body_bottom_reaction,bottomInterfaceReactionKN_KNm=bottom_interface,actualTransportedPostSectionWrenchKN_KNmm=bottom_actual,bottomInterfaceSourceResidualKN_KNm=bottom_delta,selfGRoute='Exact centred uniform body-G remains an independent vertical stress field, with bottom resultant at the actual section centroid. No favourable mass, extra patch G or lateral restraint is added.',finiteJointOrCageResistanceAccepted=False)
  posts.append(row)
 records[label]=posts
report={'schema':'str-readonly-wet-head-ideal-compression-fan/1','sourceSHA256':cases['width140']['sourceSHA256'],'authoredCageGeometrySettings':s,'analysisScriptSHA256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'cases':records,'physicalResistanceAccepted':False,'completeSignedLoadEnvelope':False,'scope':'Elementary positive-weight compression fan from actual unilateral top tractions and pad G, at the actual second-highest hoop elevation. Force and all moment equilibrium only; finite concrete nodes/bend bearing, actual hook development and compatible continuation remain unsupported. A negative weight rejects this particular fan, never the whole support.'};(D/'fan.json').write_text(json.dumps(report,indent=2,allow_nan=False)+'\n');print(json.dumps({'sha256':hashlib.sha256((D/'fan.json').read_bytes()).hexdigest(),'cases':{label:[{k:r.get(k) for k in ('id','unsupported','positiveTopLoadsOutboardVirtualFan','fanDepthMm','ties','globalFreeBodyResidualKN_KNm','headSourceWrenchResidualKN_KNm')} for r in rows] for label,rows in records.items()}}))
