"""Separate explicit upper-head cage geometry comparison, outside legacy admission."""
import copy,hashlib,json,sys,time
from pathlib import Path
ROOT=Path('/workspace/scratch/0bcaf9220286/architecture');D=Path(__file__).parent;sys.path.insert(0,str(ROOT/'project/str/studies'))
import wet_support_cage_comparison as cage
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
full=D/'width140.full.json';native=json.loads(full.read_bytes());grid_path=ROOT/'project/str/studies/current-house-grid.json';grid=json.loads(grid_path.read_bytes());s=cage.comparison_settings();s['postTopLevelRaiseMm']=10.
for path,identity in native['sourceSHA256'].items():assert sha(ROOT/path)==identity
assert sha(grid_path)==native['sourceSHA256']['project/str/studies/current-house-grid.json']
main,original=cage.build_paths(native['seatedWetSupport'],s);links=[];removed=[];authored=[]
for i,post in enumerate(native['seatedWetSupport']['posts']):
 perimeters=[r for r in original if r['id'].startswith(f'STR/WET-CAGE/post/{i}/link/') and '/cross/' not in r['id']]
 def level(path):
  zs=[p[2] for part in path['parts'] for p in part['points']];return (min(zs)+max(zs))/2
 perimeters.sort(key=level);count=len(perimeters);lo=level(perimeters[0]);old_hi=level(perimeters[-1]);target_hi=post['physicalTopZMm']-57.;delta=target_hi-old_hi
 assert count==32 and abs(delta-17)<1e-8
 authored.append({'postId':post['id'],'levelCount':count,'topPerimeterDepthMm':57.,'topLevelShiftMm':delta,'newPerimeterPitchMm':(target_hi-lo)/(count-1),'mainBarEndDepthUnchangedMm':s['postTopEndInsetMm'],'lastRetainedAffectedInnerCrossTieEndRunMm':post['physicalTopZMm']-s['postTopEndInsetMm']-(lo+(count-2)*(target_hi-lo)/(count-1)+s['postCrossTiePlaneOffsetMm'])})
for path in original:
 if not path['id'].startswith('STR/WET-CAGE/post/'):
  links.append(path);continue
 index=int(path['id'].split('/link/')[1].split('/')[0]);delta=17*index/31
 if path['id'].endswith('/link/31/cross/1'):
  removed.append(path['id']);continue
 shifted=copy.deepcopy(path);shifted['id']='REVIEW-TOP57/'+shifted['id']
 for part in shifted['parts']:
  for point in part['points']:point[2]+=delta
 links.append(shifted)
start=time.monotonic();collisions=cage.collision_report(main,links,s);closure=cage.internal_closure_report(main,links,s);cover=cage.cover_report(main+links,cage.support_solids(native['seatedWetSupport'],grid),s)
report={'schema':'str-readonly-upper-head-cage-geometry-trial/1','nativeSourceSHA256':native['sourceSHA256'],'nativeCaseId':native['nativeVertical']['native']['caseId'],'actualFullNativeResponseSHA256':sha(full),'processingSourceSHA256':{'project/str/studies/wet_support_cage_comparison.py':sha(ROOT/'project/str/studies/wet_support_cage_comparison.py'),'project/str/studies/wet-support-cage-comparison-settings.json':sha(ROOT/'project/str/studies/wet-support-cage-comparison-settings.json')},'analysisScriptSHA256':sha(__file__),'referenceSettings':s,'authoredLocalGeometry':authored,'removedPaths':removed,'mainBars':main,'links':links,'collisions':collisions,'cover':cover,'internalClosures':closure,'referenceQuantities':cage.quantity(main,original,native['seatedWetSupport'],s),'trialQuantities':cage.quantity(main,links,native['seatedWetSupport'],s),'legacySettingsAdmission':False,'headDRegionAccepted':False,'tieForceTransferAccepted':False,'anchorageAccepted':False,'nativeWeightFeedbackApplied':False,'scope':'Separate geometry experiment. Same32 perimeter levels redistributed linearly; omit only the highest positive-plane cross-tie in each post, with actual remaining endpoint run below existing100mm comparison duty. Finite force transfer, bar restraint, bending/node bearing and head resistance remain unproved. This is not an admitted topRaise27 edit or a selected cage.'}
for path,identity in native['sourceSHA256'].items():assert sha(ROOT/path)==identity
(D/'upper-head-57-geometry.json').write_text(json.dumps(report,indent=2,allow_nan=False)+'\n');print(json.dumps({'seconds':time.monotonic()-start,'sha256':sha(D/'upper-head-57-geometry.json'),'pairs':collisions['checkedIndependentPathPairs'],'pairFailures':collisions['failedPairCount'],'coverFailures':len(cover['failedPaths']),'closureFailures':len(closure['failures']),'authored':authored}))
