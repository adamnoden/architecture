import{readFileSync,writeFileSync}from'node:fs';
import{createHash}from'node:crypto';
import{readEngineeringDocument,compileEngineeringDocument}from'/workspace/scratch/0bcaf9220286/head-fan-work/compiler/reference-house/current-design/engineering-document.ts';
import{readGeorgianDesignSnapshot}from'/workspace/scratch/0bcaf9220286/head-fan-work/compiler/reference-house/current-design/georgian-source.ts';
import{applyEngineeringEdit,beginEngineeringEdit,engineeringBase,editableWetSupportId,engineeringTicket}from'/workspace/scratch/0bcaf9220286/head-fan-work/compiler/reference-house/current-design/engineering-edit.ts';
import{runEditorEngineeringRequest}from'/workspace/scratch/0bcaf9220286/head-fan-work/project/ade/browser-editor/engineering-api.ts';
const mode=process.argv[2],base=await readEngineeringDocument(readGeorgianDesignSnapshot()),stages=JSON.parse(readFileSync('/tmp/convergence-head-fan-stages.json','utf8')),
 document={...base,stages:{...stages,roofPitch:base.stages.roofPitch}},state=beginEngineeringEdit(document,'head-fan-current-proof'),changed=applyEngineeringEdit(state,{schema:'current-engineering-edit/1',units:'mm',base:engineeringBase(state),operation:{kind:'set-wet-bearing-width',assemblyId:editableWetSupportId,widthMm:140}});
if(changed.status!=='applied')throw Error(JSON.stringify(changed));
if(mode==='api'){
 const reply=await runEditorEngineeringRequest({ticket:engineeringTicket(changed.state,'actual-head-fan-api')});
 writeFileSync('/tmp/convergence-head-fan-api-result.json',JSON.stringify(reply));console.log({mode,floor:reply.floorEvidence,cage:reply.wetCage.geometry});
}else{
 const bundle=await compileEngineeringDocument(changed.state.document),floor=bundle.engineering.floorSection,actual=JSON.parse(readFileSync('/tmp/ovid-wet-pad-width-review-20261123/width140.full.json','utf8'));
 const byId=new Map(actual.nativeVertical.native.heads.map(r=>[r.id,r.reactionKN_KNm]));let error=0;for(const row of floor.native.heads)row.reactionKN_KNm.forEach((v,i)=>{error=Math.max(error,Math.abs(v-byId.get(row.id)[i]))});
 if(error>1e-6)throw Error('Actual current stage differs from source/request-matched native width140 control: '+error);
 if(floor.wetPostHeadFan?.status!=='computed-nominal-demand')throw Error('Fan failed: '+JSON.stringify(floor.wetPostHeadFan));
 writeFileSync('/tmp/convergence-head-fan-bundle-result.json',JSON.stringify(bundle));writeFileSync('/tmp/convergence-head-fan-document.json',JSON.stringify(changed.state.document));
 console.log({mode,maximum52HeadDifference:error,fan:floor.wetPostHeadFan.status,source:floor.source,posts:floor.wetPostHeadFan.posts.map(p=>({id:p.id,geometry:p.geometry,ties:p.fan.ties,residual:p.fullFreeBodyResidualKN_KNm}))});
}
