"""Genuine serial width120 q32/q64 controls; no source edits or adopted choice."""
import copy,gc,hashlib,json,os,resource,subprocess,sys,time
from pathlib import Path
ROOT=Path('/workspace/scratch/0bcaf9220286/head-fan-work');D=Path(__file__).parent
sys.path.insert(0,str(ROOT/'project/str/studies'))
from floor_section_model import load_source
from floor_section_proof import capture
from four_l_joint_observer import numerical_runtime
assert os.environ.get('OPENBLAS_NUM_THREADS')=='1' and os.environ.get('OMP_NUM_THREADS')=='1'
base=json.loads(Path('/tmp/ovid-wet-pad-width-review-20261123/width140.request.json').read_bytes());source=load_source(ROOT)
assert base['sourceSHA256']==source['identities']
for order in (32,64):
 stem=f'width120-q{order}';name=f'REVIEW-WET27-WIDTH120-Q{order}';request=copy.deepcopy(base);request['wetSupport']['padWidthMm']=120.;request['wetSupport']['bearingQuadratureOrder']=order
 req=D/(stem+'.request.json');full=D/(stem+'.full.json');manifest=D/(stem+'.capture.json')
 if any(p.exists() for p in (req,full,manifest)):raise ValueError('Existing control preserved; inspect before rerunning')
 req.write_text(json.dumps(request,allow_nan=False));before=numerical_runtime();start=time.monotonic()
 capture(name,req,full,manifest)
 assert load_source(ROOT)['identities']==source['identities'];after=numerical_runtime();assert before==after
 metrics={'name':name,'elapsedSeconds':time.monotonic()-start,'processPeakRssKiB':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'fullResultSHA256':hashlib.sha256(full.read_bytes()).hexdigest(),'requestFileSHA256':hashlib.sha256(req.read_bytes()).hexdigest(),'captureManifestFileSHA256':hashlib.sha256(manifest.read_bytes()).hexdigest(),'sourceSHA256':source['identities'],'numericalRuntime':before,'runtimeThreads':{k:os.environ[k] for k in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS')},'sourceCheckoutHEAD':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()}
 (D/(stem+'.metrics.json')).write_text(json.dumps(metrics,indent=2,allow_nan=False)+'\n');print(json.dumps({k:v for k,v in metrics.items() if k not in ('sourceSHA256','numericalRuntime')}),flush=True);gc.collect()
