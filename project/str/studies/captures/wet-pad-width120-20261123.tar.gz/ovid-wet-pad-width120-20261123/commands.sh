# Original actual serial execution; refuses to overwrite retained captures.
# OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 python3 -B /tmp/ovid-wet-pad-width120-20261123/run_controls.py
# Replay the original validated canonical capture manifests without solving:
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 python3 -B project/str/studies/floor_section_proof.py --verify-capture REVIEW-WET27-WIDTH120-Q32 /tmp/ovid-wet-pad-width120-20261123/width120-q32.request.json /tmp/ovid-wet-pad-width120-20261123/width120-q32.full.json /tmp/ovid-wet-pad-width120-20261123/width120-q32.capture.json
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 python3 -B project/str/studies/floor_section_proof.py --verify-capture REVIEW-WET27-WIDTH120-Q64 /tmp/ovid-wet-pad-width120-20261123/width120-q64.request.json /tmp/ovid-wet-pad-width120-20261123/width120-q64.full.json /tmp/ovid-wet-pad-width120-20261123/width120-q64.capture.json
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 python3 -B /tmp/ovid-wet-pad-width120-20261123/compare.py
