"""Source-bound actual120/140/220 local comparison. No adoption or new native solve."""
import copy,hashlib,json,math,sys
from pathlib import Path
ROOT=Path('/workspace/scratch/0bcaf9220286/head-fan-work');D=Path(__file__).parent;OLD=Path('/tmp/ovid-wet-pad-width-review-20261123');sys.path.insert(0,str(ROOT/'project/str/studies'))
PROCESSING_PATHS=['wet_post_head_fan.py','wet_support_cage_comparison.py','wet_bearing_refinement.py','floor_section_proof.py','finite_plate_receiver.py','wet_post_head_duties.py','wet_bearing_refinement_proof.py','wet-bearing-refinement-inputs.json','wet-support-cage-comparison-settings.json']
PROCESSING_SHA256={str((ROOT/'project/str/studies'/p).relative_to(ROOT)):hashlib.sha256((ROOT/'project/str/studies'/p).read_bytes()).hexdigest() for p in PROCESSING_PATHS}
from floor_section_model import load_source
from floor_section_proof import validate_full
from wet_bearing_refinement import assess_contact,compare_contacts
from wet_post_head_duties import post_duty
from wet_support_cage_comparison import comparison_settings,build_paths,assess
from wet_post_head_fan import cage_geometry_digest,recover_wet_head_fans,compression_fan
from wet_bearing_refinement_proof import pack_native,crop_native
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
s=comparison_settings();s['postTopLevelRaiseMm']=10.;source=load_source(ROOT);criteria=json.loads((ROOT/'project/str/studies/wet-bearing-refinement-inputs.json').read_bytes())['criteria']
files={'width120-q32':D/'width120-q32.full.json','width120-q64':D/'width120-q64.full.json','width140-q64':OLD/'width140.full.json','width220-q64':OLD/'width220.full.json'};natives={key:json.loads(path.read_bytes()) for key,path in files.items()};records={};reference_paths=None
for key,native in natives.items():
 assert native['sourceSHA256']==source['identities'];validate_full(native,native['request'],source,native['nativeVertical']['native']['caseId']);main,links=build_paths(native['seatedWetSupport'],s)
 path_identity=cage_geometry_digest({'settings':s,'mainBars':main,'links':links});reference_paths=reference_paths or path_identity;assert reference_paths==path_identity
 cage={'settings':s,'mainBars':main,'links':links,'nativeSourceSHA256':native['sourceSHA256'],'nativeCaseId':native['nativeVertical']['native']['caseId']};binding={'sourceSHA256':native['sourceSHA256'],'request':native['request'],'nativeCaseId':native['nativeVertical']['native']['caseId'],'cageGeometrySHA256':path_identity};fan=recover_wet_head_fans(native,cage,binding);contact=assess_contact(native,criteria);posts=[]
 for index,(post,row) in enumerate(zip(native['seatedWetSupport']['posts'],contact['posts'])):
  rect=row['padRectangleXYMm'];plane=row['reconstructedActualGapPlaneMm'];compliance=native['seatedWetSupport']['settings']['jointNormalComplianceMmPerMPa'];peak=max(max(0,-(plane[0]+plane[1]*x+plane[2]*y)/compliance) for x in (rect[0],rect[2]) for y in (rect[1],rect[3]))
  posts.append({'id':post['id'],'padFit':post['padFit'],'contact':row,'maximumDeclaredAffinePressureMPa':peak,'postDuty':post_duty(post),'physicalPostEndDisplacementsMmRad':post['recovery']['physicalEndDisplacementsMmRad']})
 pts=native['nativeVertical']['plate']['physicalRecovery']['points'];lookup={tuple(r['xyMm']):r for r in pts};g=native['seatedWetSupport']['settings'];x=g['beamAxisXMm'];half=g['beamWidthMm']/2;trace=[]
 for station in native['seatedWetSupport']['receiver']['stations']:
  y=station['u'];a=lookup.get((x-half,y));b=lookup.get((x+half,y))
  if a is not None and b is not None:trace.append({'yMm':y,'axisVerticalDisplacementMm':(a['displacementMmRad'][0]+b['displacementMmRad'][0])/2})
 records[key]={'executionRecord':json.loads(files[key].with_name(files[key].name.replace('.full.json','.metrics.json')).read_bytes()),'captureManifestSHA256':sha(files[key].with_name(files[key].name.replace('.full.json','.capture.json'))),'caseId':native['nativeVertical']['native']['caseId'],'fullResponseSHA256':sha(files[key]),'exactRequest':native['request'],'exactCroppedNativeInput':pack_native(crop_native(native)),'retainedCropReconstructsFullNativeResponse':False,'contacts':posts,'fan':fan,'cageGeometrySHA256':path_identity,'padTotalPhysicalGKN':sum(p['padPhysicalGKN'] for p in native['seatedWetSupport']['posts']),'mass':native['mass'],'nativeGlobalMaximumFrameTranslationMm':native['nativeVertical']['native']['maximumFrameTranslationMm'],'sampledBeamAxisDisplacements':trace,'maximumAbsoluteSampledBeamAxisDisplacementMm':max(abs(r['axisVerticalDisplacementMm']) for r in trace),'sampleScope':'Opposite actual physical plate trace averages at named beam nodes, not continuous maximum or an SLS pass.','rawFloorPointBendingPlusTwist':native['plateBending']['maximumAbsoluteBendingPlusTwistingKNmPerM'],'floorNecessaryStrainSection':native['floorReinforcement']['necessaryStrainCompatibleSection']}
for key in ('width140-q64','width220-q64'):
 a=copy.deepcopy(natives[key]['request']);b=copy.deepcopy(natives['width120-q64']['request']);a['wetSupport'].pop('padWidthMm');b['wetSupport'].pop('padWidthMm');assert a==b
base=natives['width120-q64'];cage_result=assess(base,json.loads((ROOT/'project/str/studies/current-house-grid.json').read_bytes()),s,with_collisions=False);(D/'width120-q64.cage.json').write_text(json.dumps(cage_result,allow_nan=False))
rows=cage_result['simultaneousSectionScreens']['beamCuts'];valid=[r for r in rows if r['sectionRatio'] is not None];screens={'cageAssessmentSHA256':sha(D/'width120-q64.cage.json'),'nominalSectionGovernor':max(valid,key=lambda r:r['sectionRatio']),'nominalLinkFlowGovernor':max(rows,key=lambda r:r['necessaryThinCellLinkFlowRatio']),'unsupportedDRegionRows':sum(r['sectionRatio'] is None for r in rows),'rowCount':len(rows),'quantities':cage_result['quantities'],'geometryEvidence':'Exact generated path digest equals140/220 controls. Existing geometry proof is unchanged; this replay does not rerun collisions or claim installed acceptance.'}
def changes(a,b):
 ah={r['id']:r['reactionKN_KNm'] for r in a['nativeVertical']['native']['heads']};bh={r['id']:r['reactionKN_KNm'] for r in b['nativeVertical']['native']['heads']};assert set(ah)==set(bh)
 result=[{'id':k,'from':ah[k],'to':bh[k],'difference':[v-u for u,v in zip(ah[k],bh[k])]} for k in sorted(ah)];return {'heads':result,'maximum':max(({'id':r['id'],'component':i,'difference':v} for r in result for i,v in enumerate(r['difference'])),key=lambda r:abs(r['difference']))}
components=('axialCompressionKN','shearYKN','shearZKN','torsionKNm','bendingYKNm','bendingZKNm')
def beam(n):
 rows=[r for key in ('memberCuts','interiorMemberCuts') for r in n['nativeVertical']['native'][key] if r['memberId'].startswith('WET-SUPPORT/beam/')];return {'cuts':rows,'inspectionGovernors':{k:max(rows,key=lambda r:abs(r[k])) for k in components},'scope':'Each governor retains its own simultaneous six-action row. Independent component governors are not combined.'}
placement=[]
for key in ('width120-q64','width140-q64'):
 g=natives[key]['seatedWetSupport']['settings'];fan=records[key]['fan'];points=[]
 for post in fan['posts']:
  geom=post['geometry'];axes=geom['halfAxesXYMm'];pad=[g['padWidthMm']/2,g['padLengthMm']/2];relative=g['combinedRelativePlacementToleranceMm'];cage_setting=s['cageInstallationToleranceMm'];fabrication=s['linkFabricationToleranceMm'];reserve=[a-p-relative-cage_setting-fabrication for a,p in zip(axes,pad)]
  if post['fan']['status']=='computed-nominal-equilibrium':
   # Static local geometric probes only. No new native pressure law, reaction or physical tolerance acceptance.
   for sx in (-1,1):
    for sy in (-1,1):
     loads=copy.deepcopy(post['fan']['inputLoads']);delta=[sx*(relative+cage_setting+fabrication),sy*(relative+cage_setting+fabrication)]
     for r in loads:r['xyMm']=[r['xyMm'][i]+delta[i] for i in (0,1)]
     result=compression_fan(loads,axes,geom['depthMm']);points.append({'postId':post['id'],'relativeXYShiftMm':delta,'status':result['status'],'minimumWeight':result.get('minimumBranchWeight'),'diagnostics':result.get('diagnostics',[])})
  placement.append({'case':key,'postId':post['id'],'nominalVirtualHalfAxesXYMm':axes,'physicalPadHalfDimensionsXYMm':pad,'independentBoundsMm':{'relativePadMember':relative,'cageInstallation':cage_setting,'linkFabrication':fabrication},'positiveFanDomainEnvelopeReserveXYMm':reserve})
 placement.append({'case':key,'nominalForceGeometricProbes':points,'scope':'Sampled forces moved relative to nominal virtual axes as a local geometric probe only. These are not coupled re-equilibrated placement trials, finite node/bar reserve or complete tolerance-domain acceptance.'})
report={'schema':'str-width120-current-native-comparison/1','sourceSHA256':source['identities'],'analysisProducerSHA256':sha(__file__),'methodSourceSHA256':PROCESSING_SHA256,'controls':records,'width120Order32To64':compare_contacts(natives['width120-q32'],base,criteria),'width140To120Heads':changes(natives['width140-q64'],base),'width220To120Heads':changes(natives['width220-q64'],base),'beam':{k:beam(n) for k,n in natives.items() if k.endswith('q64')},'width120CageScreens':screens,'geometricPlacementDomain':placement,'physicalContactAccepted':False,'headDRegionAccepted':False,'toleranceDomainAccepted':False,'anchorageAccepted':False,'fullSectionContinuationAccepted':False,'completeSignedLoadEnvelope':False,'wholeHouseAccepted':False,'candidateAccepted':False}
assert load_source(ROOT)['identities']==source['identities'];assert PROCESSING_SHA256=={path:sha(ROOT/path) for path in PROCESSING_SHA256};(D/'comparison.json').write_text(json.dumps(report,indent=2,allow_nan=False)+'\n');print(json.dumps({'sha256':sha(D/'comparison.json'),'refinementPassing':report['width120Order32To64']['numericalRefinementPassing'],'maxHeadChange140To120':report['width140To120Heads']['maximum'],'maxHeadChange220To120':report['width220To120Heads']['maximum'],'cageSectionRatio':screens['nominalSectionGovernor']['sectionRatio'],'cageLinkRatio':screens['nominalLinkFlowGovernor']['necessaryThinCellLinkFlowRatio']}))
